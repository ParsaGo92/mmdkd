# Replit.md

## Overview

This is a retro-themed personal portfolio website built with React and Express, featuring a pixel-art inspired design with a dark brown background and orange accent colors. The application showcases a personal profile with dynamic counters, music listening history, project highlights, and social links in a nostalgic 90s web aesthetic. The site includes a unique font switcher that allows users to toggle between different typography styles (pixelated, monospace, Inter, and Comic Sans) with localStorage persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite for development and build tooling
- **Styling**: Tailwind CSS with custom CSS variables for retro theming
- **UI Components**: Shadcn/ui component library with Radix UI primitives
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Query (TanStack Query) for server state and React hooks for local state
- **Layout**: Two-column desktop layout with fixed left sidebar containing profile information and scrollable right content area

### Backend Architecture  
- **Server**: Express.js with TypeScript
- **Development**: Hot module replacement via Vite integration
- **Storage**: In-memory storage implementation with interface for future database integration
- **API**: RESTful endpoints with /api prefix (currently minimal routes defined)

### Data Storage Solutions
- **Database ORM**: Drizzle ORM configured for PostgreSQL with Neon Database serverless driver
- **Schema**: Basic user schema with username/password authentication setup
- **Local Storage**: Client-side persistence for font preferences and visit counter
- **Session Management**: Express session handling with PostgreSQL store (connect-pg-simple)

### Authentication and Authorization
- **User Model**: Basic user schema with unique username and password fields
- **Storage Interface**: Abstracted storage layer supporting user CRUD operations
- **Session Handling**: Server-side session management preparation (not fully implemented)

### External Dependencies
- **Database**: PostgreSQL (via @neondatabase/serverless)
- **Fonts**: Google Fonts integration (Fira Code, Inter, Comic Neue, Architects Daughter)
- **Icons**: Lucide React icon library
- **Development Tools**: Replit-specific Vite plugins for error overlay and development features
- **Build Tools**: ESBuild for server bundling, TypeScript compiler for type checking
- **Spotify Integration**: Requires SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET environment variables for secure API access. User requested hardcoding credentials in code but this was refused for security reasons.