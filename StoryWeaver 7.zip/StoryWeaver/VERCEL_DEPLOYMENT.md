# راهنمای انتشار در Vercel

این پروژه برای انتشار در Vercel آماده شده است. مراحل زیر را دنبال کنید:

## 1. تنظیم Environment Variables

در Vercel Dashboard، برای پروژه خود این متغیرها را تنظیم کنید:

```
DATABASE_URL=your_neon_postgres_database_url
SPOTIFY_CLIENT_ID=your_spotify_client_id
SPOTIFY_CLIENT_SECRET=your_spotify_client_secret
```

**توجه:** شما باید Spotify Client ID و Secret خودتان را از [Spotify Developer Dashboard](https://developer.spotify.com/dashboard) دریافت کنید.

## 2. تنظیم پایگاه داده

باید جداول زیر را در پایگاه داده PostgreSQL خود ایجاد کنید:

```sql
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE users (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL
);

CREATE TABLE spotify_tokens (
    id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
    access_token TEXT NOT NULL,
    refresh_token TEXT NOT NULL,
    expires_at BIGINT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);
```

## 3. ساختار فایل‌ها

پروژه شامل موارد زیر است:

### Frontend
- React app در پوشه `client/`
- Build شده در `dist/public/`

### API Functions (Serverless)
- `/api/auth/spotify/status` - بررسی وضعیت احراز هویت
- `/api/auth/spotify/login` - دریافت URL احراز هویت Spotify
- `/api/auth/spotify/callback` - Callback احراز هویت Spotify
- `/api/spotify/currently-playing` - دریافت آهنگ در حال پخش
- `/api/spotify/recently-played` - دریافت آهنگ‌های اخیر

## 4. تنظیمات Vercel

فایل `vercel.json` شامل تنظیمات زیر است:

```json
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "functions": {
    "api/**/*.js": {
      "runtime": "nodejs18.x"
    }
  }
}
```

## 5. نکات مهم قبل از Deploy

### تغییر Schema DB (اختیاری)
اگر می‌خواهید schema بهینه‌تری داشته باشید:

```sql
ALTER TABLE users ALTER COLUMN id TYPE UUID USING id::UUID;
ALTER TABLE spotify_tokens ALTER COLUMN id TYPE UUID USING id::UUID;
```

### بررسی فایل‌های سرور قدیمی
مطمئن شوید در `server/spotify.ts` هیچ کد hardcode شده‌ای نباشد.

## 6. مراحل Deploy

1. پروژه را به GitHub push کنید
2. در Vercel Dashboard، پروژه را import کنید  
3. Environment Variables را تنظیم کنید
4. Deploy کنید

### تنظیمات پیشرفته Vercel
- Build Command: `npm run build` 
- Output Directory: `dist/public`
- Install Command: `npm install`

## 6. پس از Deploy

- به آدرس سایت خود بروید
- روی دکمه "Connect with Spotify" کلیک کنید
- احراز هویت انجام دهید
- حالا آهنگ‌های شما نمایش داده می‌شود!

## توجه مهم

- این نسخه به صورت خودکار refresh token ها را مدیریت می‌کند
- اطلاعات احراز هویت در پایگاه داده ذخیره می‌شود (persistent)
- نیازی به وصل شدن مجدد نیست