import { useState, useEffect } from 'react';

export function useAgeCounter() {
  return '17';
}
